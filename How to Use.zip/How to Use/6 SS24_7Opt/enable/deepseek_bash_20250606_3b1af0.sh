sudo systemctl daemon-reload
sudo systemctl enable mining-optimizer
sudo systemctl start mining-optimizer