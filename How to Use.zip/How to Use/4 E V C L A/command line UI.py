#!/usr/bin/env python3
import argparse
import sys
from crypto_mining_optimizer import CryptoMiningOptimizer

def main():
    parser = argparse.ArgumentParser(description="Crypto Mining Optimization Tool")
    
    parser.add_argument('--single-run', action='store_true', help='Run one optimization cycle')
    parser.add_argument('--continuous', action='store_true', help='Run continuously')
    parser.add_argument('--interval', type=int, default=15, 
                       help='Minutes between cycles (default: 15)')
    parser.add_argument('--log', type=str, help='Log file path')
    
    args = parser.parse_args()
    
    optimizer = CryptoMiningOptimizer()
    
    if args.log:
        # Set up logging to file
        sys.stdout = open(args.log, 'a')
        sys.stderr = sys.stdout
    
    try:
        if args.single_run:
            optimizer.run_optimization_cycle()
        elif args.continuous:
            optimizer.continuous_optimization(args.interval)
        else:
            print("Please specify either --single-run or --continuous")
    except KeyboardInterrupt:
        print("\nOptimization stopped by user")
    finally:
        if args.log:
            sys.stdout.close()

if __name__ == "__main__":
    main()